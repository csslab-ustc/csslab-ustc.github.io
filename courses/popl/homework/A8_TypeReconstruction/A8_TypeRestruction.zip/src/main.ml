(* the entry point *)
Lambda.unit_test();
Let.unit_test();
