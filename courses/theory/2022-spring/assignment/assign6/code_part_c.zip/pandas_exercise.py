import pandas as pd

# Here you have to do some exercises to familiarize yourself with pandas.
# Especially some basic operations based on pd.Series and pd.DataFrame

# TODO: Create a Series called `ser`:
#   x1  1.0
#   x2  -1.0
#   x3  2.0

# Your code here
# ser =


# TODO: Create a DataFrame called `df`:
#        x0   x1   x2
#   s0 -1.1  0.8 -2.5
#   s1 -1.3 -1.0 -1.2
#   s2  1.7  1.8  2.1
#   s3  0.9  0.3  1.1

# Your code here
# df =


# TODO: select `df` by column="x1":

# Your code here


# TODO: select `df` by third row and first column:

# Your code here


# TODO: change `df`'s column's name x0 to y0:

# Your code here


# TODO: select `df` where column's name start with x:

# Your code here


# TODO: change `ser`'s index to [y0,x1,x2]:

# Your code here


# TODO: change `df` where column y0 multiply -1.5:

# Your code here


# TODO: calculate `df` multiply `ser`:

# Your code here


# TODO: merge `ser` with the result of previous task:

# Your code here

