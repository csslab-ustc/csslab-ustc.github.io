from typing import List
import unittest
from dataclasses import dataclass

from z3 import *

from counter import counter


##################################
# The abstract syntax for the Tac (three address src) language:
"""
S ::= x=y | x=y+z | x=y-z | x=y*z | x=y/z
F ::= f(x1, ..., xn){S;* return x;}
"""

# variable
@dataclass(repr=False)
class Var:
    var: str

    def __str__(self):
        return f"{self.var}"
    
    def __repr__(self):
        return self.__str__()

# statement
@dataclass(repr=False)
class Stmt:
    def __repr__(self):
        return self.__str__()


@dataclass(repr=False)
class AssignVar(Stmt):
    x: Var
    y: Var

    # Exercise 6-1: finish the `__str__` method in data structure AssignVar
    def __str__(self):
        raise NotImplementedError('TODO: Your code here!') 

@dataclass(repr=False)
class AssignAdd(Stmt):
    x: Var
    y: Var
    z: Var

    # Exercise 6-2: finish the `__str__` method in data structure AssignAdd
    def __str__(self):
        raise NotImplementedError('TODO: Your code here!') 

@dataclass(repr=False)
class AssignSub(Stmt):
    x: Var
    y: Var
    z: Var

    # Exercise 6-3: finish the `__str__` method in data structure AssignSub
    def __str__(self):
        raise NotImplementedError('TODO: Your code here!') 
        

@dataclass(repr=False)
class AssignMul(Stmt):
    x: Var
    y: Var
    z: Var

    # Exercise 6-4: finish the `__str__` method in data structure AssignMul
    def __str__(self):
        raise NotImplementedError('TODO: Your code here!') 


class AssignDiv(Stmt):
    x: Var
    y: Var
    z: Var

    # Exercise 6-5: finish the `__str__` method in data structure AssignDiv
    def __str__(self):
        raise NotImplementedError('TODO: Your code here!') 


# function:
@dataclass(repr=False)
class Function:
    name: str
    args: List[Var]
    stmts: List[Stmt]
    ret: Var

    # Exercise 6-6: finish the `__str__` method in data structure Function
    def __str__(self):
        raise NotImplementedError('TODO: Your code here!') 


###############################################
# SSA conversion:

# Exercise 7: Finish the SSA conversion function `to_ssa_stmt()`
# take a function 'f', convert it to SSA
def to_ssa_func(func: Function) -> Function:
    var_map = {arg.var: arg.var for arg in func.args}
    fresh_var = counter(prefix=f"tac_{func.name}")
    
    def to_ssa_stmt(stmt):
        raise NotImplementedError('TODO: Your code here!') 
    
    new_stmts = [to_ssa_stmt(stmt) for stmt in func.stmts]
    return Function(func.name, func.args, new_stmts, Var(var_map[func.ret.var]))
    

    


###############################################
# Exercise 8-1: Finished the `gen_cons_stmt` function to generate 
# constraints form TAC statements
# Generate Z3 constraints:
def gen_cons_stmt(stmt: Stmt) -> BoolRef:
    raise NotImplementedError('TODO: Your code here!') 


# Exercise 8-2: Finished the `gen_cons_stmt` function to 
# generate constraints form TAC function 
def gen_cons_func(func: Function) -> List[BoolRef]:
    raise NotImplementedError('TODO: Your code here!') 


###############################################
# Tests

test_case = Function('f',
                     [Var('s1'), Var('s2'), Var('t1'), Var('t2')],
                     [AssignAdd(Var('a'), Var('s1'), Var('t1')),
                      AssignAdd(Var('b'), Var('s2'), Var('t2')),
                      AssignMul(Var('c'), Var('a'), Var('b')),
                      AssignMul(Var('b'), Var('c'), Var('s1')),
                      AssignVar(Var('z'), Var('b'))],
                     Var('z'))


class TestTac(unittest.TestCase):
    ssa = to_ssa_func(test_case)
    cons = gen_cons_func(ssa)

    def test_print(self):
        res = ("f(s1, s2, t1, t2){\n\ta = s1 + t1;\n\tb = s2 + t2;\n\tc = a * b;\n\t"
               "b = c * s1;\n\tz = b;\n\treturn z;\n}")

        # f(s1, s2, t1, t2){
        #   a = s1 + t1;
        #   b = s2 + t2;
        #   c = a * b;
        #   b = c * s1;
        #   z = b;
        #   return z;
        # }
        print(test_case)
        self.assertEqual(str(test_case), res)

    def test_to_ssa(self):
        res = ("f(s1, s2, t1, t2){\n\t_tac_f_0 = s1 + t1;\n\t_tac_f_1 = s2 + t2;\n\t_tac_f_2 = _tac_f_0 * _tac_f_1;\n\t"
               "_tac_f_3 = _tac_f_2 * s1;\n\t_tac_f_4 = _tac_f_3;\n\treturn _tac_f_4;\n}")

        # f(s1, s2, t1, t2){
        #   _tac_f_0 = s1 + t1;
        #   _tac_f_1 = s2 + t2;
        #   _tac_f_2 = _tac_f_0 * _tac_f_1;
        #   _tac_f_3 = _tac_f_2 * s1;
        #   _tac_f_4 = _tac_f_3;
        #   return _tac_f_4;
        # }

        print(self.ssa)
        self.assertEqual(str(self.ssa), res)

    def test_gen_cons(self):
        res = ("[_tac_f_0 == f_add(s1, t1),"
               " _tac_f_1 == f_add(s2, t2),"
               " _tac_f_2 == f_mul(_tac_f_0, _tac_f_1),"
               " _tac_f_3 == f_mul(_tac_f_2, s1),"
               " _tac_f_4 == _tac_f_3]")
        print(self.cons)
        self.assertEqual(str(self.cons), res)


if __name__ == '__main__':
   unittest.main()


