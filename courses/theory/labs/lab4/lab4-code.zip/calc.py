from dataclasses import dataclass, field
from enum import Enum
from typing import List

from z3 import *

from counter import counter


##################################
# The abstract syntax for the Calc language:
'''
bop ::= + | - | * | /
E   ::= x | E bop E
S   ::= x=E
F   ::= f(x1, …, xn){S;* return E;}
'''


# binary operator
class BOp(Enum):
    ADD = "+"
    SUB = "-"
    MUL = "*"
    DIV = "/"


# expression
@dataclass(repr=False)
class Expr:
    def __repr__(self):
        return self.__str__()

@dataclass(repr=False)
class ExprVar(Expr):
    var: str

    def __str__(self):
        return f"{self.var}"

@dataclass(repr=False)
class ExprBop(Expr):
    left: Expr
    right: Expr
    bop: BOp

    def __str__(self):
        if isinstance(self.left, ExprBop):
            left_str = f"({self.left})"
        else:
            left_str = f"{self.left}"

        if isinstance(self.right, ExprBop):
            right_str = f"({self.right})"
        else:
            right_str = f"{self.right}"

        return f"{left_str} {self.bop.value} {right_str}"


# statement
@dataclass(repr=False)
class Stmt:
    level: int = field(default=0, kw_only=True)

    def __repr__(self):
        return self.__str__()

@dataclass(repr=False)
class StmtAssign(Stmt):
    var: ExprVar
    expr: Expr

    def __str__(self):
        return f"{self.level * '\t'}{self.var} = {self.expr};\n"


# function:
@dataclass
class Function:
    name: str
    args: List[ExprVar]
    stmts: List[Stmt]
    ret: ExprVar
    
    def __str__(self):
        arg_str = ",".join([str(arg)for arg in self.args])
        for stmt in self.stmts:
            stmt.level += 1

        stmts_str = "".join([str(stmt) for stmt in self.stmts])

        return (f"{self.name}({arg_str}){{\n"
                f"{stmts_str}"
                f"\treturn {self.ret};\n"
                f"}}\n")


###############################################
# SSA conversion:

# take a function 'func', convert it to SSA
def to_ssa_func(func: Function) -> Function:
    # a map from variable to new variable:
    # init it by putting every argument into the map
    var_map = {arg.var: arg.var for arg in func.args}

    # fresh variable generator
    fresh_var = counter(prefix=f"calc_{func.name}")

    def to_ssa_expr(expr: Expr) -> Expr:
        match expr:
            case ExprVar(var):
                return ExprVar(var_map[var])
            case ExprBop(left, right, bop):
                return ExprBop(to_ssa_expr(left), to_ssa_expr(right), bop)

    def to_ssa_stmt(stmt: Stmt) -> Stmt:
        if isinstance(stmt, StmtAssign):
            new_expr = to_ssa_expr(stmt.expr)
            new_var = next(fresh_var)
            var_map[stmt.var.var] = new_var
            return StmtAssign(ExprVar(new_var), new_expr)

    # to convert each statement one by one:
    new_stmts = [to_ssa_stmt(stmt) for stmt in func.stmts]

    return Function(func.name, func.args, new_stmts, ExprVar(var_map[func.ret.var]))


###############################################
# Generate Z3 constraints:
def gen_cons_exp(expr: Expr) -> BoolRef:
    match expr:
        case ExprVar(var):
            return Const(var, DeclareSort('S'))
        case ExprBop(left, right, bop):
            match bop:
                case BOp.ADD:
                    func_name = "f_add"
                case BOp.SUB:
                    func_name = "f_sub"
                case BOp.MUL:
                    func_name = "f_mul"
                case BOp.DIV:
                    func_name = "f_div"
                case _:
                    raise ValueError("unknown binary operator")
            
            left = gen_cons_exp(left)
            right = gen_cons_exp(right)
            
            return z3.Function(func_name,
                               DeclareSort('S'),
                               DeclareSort('S'),
                               DeclareSort('S')).__call__(left, right)


def gen_cons_stm(stmt):
    if isinstance(stmt, StmtAssign):
        return Const(stmt.var.var, DeclareSort('S')) == gen_cons_exp(stmt.expr)


def gen_cons_func(func):
    return [gen_cons_stm(stmt) for stmt in func.stmts]


# a sample program:
sample_f = Function('f',
                    [ExprVar('s1'), ExprVar('s2'), ExprVar('t1'), ExprVar('t2')],
                    [StmtAssign(ExprVar('z'), ExprBop(ExprBop(ExprVar('s1'), ExprVar('t1'), BOp.ADD),
                                                      ExprBop(ExprVar('s2'), ExprVar('t2'), BOp.ADD),
                                                      BOp.MUL)),
                     StmtAssign(ExprVar('z'), ExprBop(ExprVar('z'), ExprVar('s1'), BOp.MUL))],
                    ExprVar('z'))

if __name__ == '__main__':
    # print the original program
    print(sample_f)
    # convert it to SSA
    new_f = to_ssa_func(sample_f)
    # print the converted program
    print(new_f)
    # generate Z3 constraints
    print(gen_cons_func(new_f))
