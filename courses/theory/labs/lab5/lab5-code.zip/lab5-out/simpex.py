from typing import List
import unittest
from enum import Enum, auto

import pandas as pd
from pandas.testing import assert_series_equal

from constraint import Constraint, IllegalConstraintError
from tableau import Tableau

VERBOSE = True


class Status(Enum):
    UNSAT = auto()
    SAT = auto()
    UNDECIDED = auto()


def simplex(constraints: List[Constraint]) -> dict | str:
    result = {}
    print("===>Solving Constraints:")
    if not constraints:
        return result

    basic_var_amount = len(constraints[0].coefficients)
    for constraint in constraints:
        if len(constraint.coefficients) != basic_var_amount:
            raise IllegalConstraintError(constraint)
        print(constraint)

    tab = Tableau(constraints)

    # Challenge : finish the simplex algorithm following the skeleton of the algorithm:
    # simplex(){
    #     tab = constructTableau();
    #     while(True){
    #         for(each additional var si){
    #             if(si violates its constraint){
    #                 if(there is a suitable xj){
    #                     pivot(si, xj);
    #                     update additional var
    #                 }
    #                 else return UNSAT;
    #             }
    #         }
    #         if (each additional var satisfies its constraint)
    #             return SAT;
    #     }
    # }
    # Your code here:
    # @begin
    constraint_values = pd.Series(data=[constraint.value for constraint in constraints],
                                  index=tab.row_names, dtype="float64")
    basic_var_values = pd.Series(data=[0]*basic_var_amount, index=tab.col_names, dtype="float64")
    add_var_values = tab.data @ basic_var_values
    status = Status.UNDECIDED
    while status is Status.UNDECIDED:
        add_var_values = (tab.data @ basic_var_values).round(decimals=6)
        has_violate_constraint = False
        for idx, value in add_var_values.items():
            if not idx.startswith("s"):
                continue

            if value < constraint_values.loc[idx]:
                has_violate_constraint = True
                has_suitable_basic_var = False
                for col in tab.data.columns:
                    if col.startswith("x") and tab.data.loc[idx, col] != 0:
                        has_suitable_basic_var = True

                        if VERBOSE:
                            print("===> Before Pivot")
                            print(tab)
                            print(f"Pivot[ row:{idx}, column:{col} ]")

                        tab.pivot(idx, col)

                        if VERBOSE:
                            print("===> After Pivot")
                            print(tab)

                        basic_var_values.loc[col] = constraint_values.loc[idx]
                        basic_var_values = basic_var_values.rename({col: idx})

                        break

                if not has_suitable_basic_var:
                    status = Status.UNSAT
                    break
                
                break

        if not has_violate_constraint:
            status = Status.SAT

    if status is Status.SAT:
        for idx, value in pd.concat([basic_var_values, add_var_values]).items():
            if idx.startswith("x"):
                result[idx] = value
    else:
        result = "no solution"
    # @end
    
    print(f"===>Solving result is {result}")
    return result


class TestSimplex(unittest.TestCase):

    def test_simplex_sat(self):
        case = [Constraint([1, 1], 2), Constraint([2, -1], 0), Constraint([-1, 2], 1)]
        result = simplex(case)
        assert_series_equal(pd.Series(result), pd.Series({"x0": 1.0, "x1": 1.0}))

    def test_simplex_unsat(self):
        case = [Constraint([-1, 1, 0], 0), Constraint([-1, 0, 1], 0), Constraint([1, -1, -2], 0),
                Constraint([0, 0, 1], 1)]
        result = simplex(case)
        self.assertEqual(result, "no solution")


if __name__ == '__main__':
    unittest.main()
