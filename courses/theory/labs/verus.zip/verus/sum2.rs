use vstd::prelude::*;

// a verus program starts with the key word "verus!"
verus! {

// a specification for the function "sum"
spec fn sum_spec(n: nat) -> nat
    decreases n
{
    if(n==0){
        0
    }else{
        n+sum_spec((n-1) as nat)
    }
}

fn sum(n: i32) -> (result: i32)
    requires n>=0,
        n<=1000
    ensures result==sum_spec(n as nat)
{
    let mut i = 1;
    let mut s = 0;
    while(i <= n)
        invariant n>=0,
            n<=1000,
            i>=1,
            i <= n+1,
            s <= 1000*i,
            s == sum_spec((i-1) as nat)
    {
        s += i;
        i += 1;
    }
    return s;
}

}




