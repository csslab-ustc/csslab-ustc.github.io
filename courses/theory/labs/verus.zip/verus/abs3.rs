use vstd::prelude::*;

// a verus program starts with the key word "verus!"
verus! {

// a specification specifying the property of the "abs" function.
spec fn abs_spec(x: i32) -> i32
{
    if(x>=0){
        x
    }else{
        (0-x) as i32
    }
}

// basic usage of pre- and post-conditions
fn abs(x: i32) -> (result: i32)
    requires x != i32::MIN, // this assertion dismisses integer overflows
    // a stronger post-condition
    ensures result==abs_spec(x)
{
    if(x>=0) {
        return x;
    }else{
        return 0-x;
    }
}

}




