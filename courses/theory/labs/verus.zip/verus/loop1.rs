use vstd::prelude::*;

// a verus program starts with the key word "verus!"
verus! {

fn f(mut x: i32) -> (result: i32)
    requires true
    ensures result==5
{
    while(x < 5)
    {
        x += 1;
    }
    return x;
}

}




