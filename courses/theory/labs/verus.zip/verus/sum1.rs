use vstd::prelude::*;

// a verus program starts with the key word "verus!"
verus! {

fn sum(n: i32) -> (result: i32)
    requires n>=0,
        n<=1000
    ensures result==n*(n+1)/2
{
    let mut i = 1;
    let mut s = 0;
    while(i <= n)
        invariant n>=0,
            n<=1000,
            i>=1,
            i <= n+1,
            s <= 1000*i,
            s == (i-1)*i/2
    {
        let mut t = s + i;
        assert(t==i*(i+1)/2) by (nonlinear_arith)
            requires(s==(i-1)*i/2 && t==s+i);
        s = t;
        i += 1;
    }
    return s;
}

}




