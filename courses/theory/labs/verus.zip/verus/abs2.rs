use vstd::prelude::*;

// a verus program starts with the key word "verus!"
verus! {

// basic usage of pre- and post-conditions
fn abs(x: i32) -> (result: i32)
    requires x != i32::MIN, // this assertion dismisses integer overflows
    // a stronger post-condition
    ensures result==if(x>=0){x}else{(0-x) as i32}
{
    if(x>=0) {
        return x;
    }else{
        return 0-x;
    }
}

}




