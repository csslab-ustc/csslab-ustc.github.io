from imp_ast import *
import prover


# a utility class to represent the code you should fill in.
class Todo(Exception):
    pass


def var_substitution(var: str, exp: Exp, post_cond: Exp):
    if isinstance(post_cond, ExpNum):
        return post_cond

    if isinstance(post_cond, ExpVar):
        if post_cond.var == var:
            return exp
        else:
            return post_cond

    if isinstance(post_cond, ExpNeg):
        return ExpNeg(var_substitution(var, exp, post_cond.exp))

    if isinstance(post_cond, ExpBop):
        left = var_substitution(var, exp, post_cond.left)
        right = var_substitution(var, exp, post_cond.right)
        return ExpBop(left, right, post_cond.bop)

    if isinstance(post_cond, ExpUni):
        if var in post_cond.vars_set:
            return post_cond
        else:
            return ExpUni(post_cond.vars_set, var_substitution(var, exp, post_cond.exp))


def vc_stms(stms: List[Stm],  post_cond: Exp):
    for stm in reversed(stms):
        post_cond = vc_stm(stm, post_cond)

    return post_cond


def vc_stm(stm: Stm, post_cond: Exp):
    if isinstance(stm, StmAssign):
        return var_substitution(stm.var, stm.exp, post_cond)

    if isinstance(stm, StmIf):
        post_cond_then = vc_stms(stm.then_stms, post_cond)
        post_cond_else = vc_stms(stm.else_stms, post_cond)

        return ExpBop(ExpBop(stm.exp, post_cond_then, BOp.IM),
                      ExpBop(ExpNeg(stm.exp), post_cond_else, BOp.IM),
                      BOp.AND)

    if isinstance(stm, StmWhile):
        post_cond_stms = vc_stms(stm.stms, stm.inv)
        return ExpBop(stm.inv,
                      ExpUni(stm.modified_vars,
                             ExpBop(stm.inv,
                                    ExpBop(ExpBop(stm.exp, post_cond_stms, BOp.IM),
                                           ExpBop(ExpNeg(stm.exp), post_cond, BOp.IM),
                                           BOp.AND),
                                    BOp.IM)),
                      BOp.AND)


########################################
# This function will scan through a given function "f", generate and
# return a verification condition:
# VC(pre f(){S} post) = pre → VC(S, post)
def vc(func: Function) -> Exp:
    post_cond = var_substitution("result", func.ret, func.post)
    return ExpBop(func.pre, vc_stms(func.stms, post_cond), BOp.IM)


if __name__ == '__main__':
    # TODO: Exercise 4: perform verification condition generation, get the verification condition
    #
    # should print:
    #
    # (n <= 0) -> ((n <= 5) && ∀(n).((n <= 5) -> (((n < 5) -> ((n + 1) <= 5)) && (~(n < 5) -> (n == 5)))))
    # the number of nodes in VC:  15
    #
    # (n >= 0) -> (((0 <= (n + 1)) && ((2 * 0) == (0 * (0 - 1)))) && ∀(s,i).(((i <= (n + 1)) && ((2 * s) ==
    # (i * (i - 1)))) -> (((i <= n) -> (((i + 1) <= (n + 1)) && ((2 * (s + i)) == ((i + 1) * ((i + 1) - 1))))) &&
    # (~(i <= n) -> ((2 * s) == (n * (n + 1)))))))
    # the number of nodes in VC:  39
    #
    fill_in_modified_vars(fun_foo)
    vc_foo = vc(fun_foo)
    print(vc_foo)
    print("the number of nodes in VC: ", exp_num_nodes(vc_foo))

    fill_in_modified_vars(fun_sum)
    vc_sum = vc(fun_sum)
    print(vc_sum)
    print("the number of nodes in VC: ", exp_num_nodes(vc_sum))

    # TODO: Exercise 5: prove the generated vc with prove_vc(the_vc), you
    #  need to complete the code in prover.py file
    #
    # should output:
    #
    # Implies(n <= 0,
    #         And(n <= 5,
    #             ForAll(n,
    #                    Implies(n <= 5,
    #                            And(Implies(n < 5, n + 1 <= 5),
    #                                Implies(Not(n < 5), n == 5))))))
    #
    # Implies(n >= 0,
    #         And(And(n + 1 >= 0, True),
    #             ForAll([s, i],
    #                    Implies(And(i <= n + 1, 2*s == i*(i - 1)),
    #                            And(Implies(i <= n,
    #                                        And(i + 1 <= n + 1,
    #                                         2*(s + i) ==
    #                                         (i + 1)*(i + 1 - 1))),
    #                                Implies(Not(i <= n),
    #                                        2*s == n*(n + 1)))))))
    #
    z3_foo_vc = prover.vc_2_z3(vc_foo)
    z3_sum_vc = prover.vc_2_z3(vc_sum)
    print(z3_foo_vc)
    print(z3_sum_vc)

    #
    # True
    # True
    #
    print(prover.prove_vc(z3_foo_vc))
    print(prover.prove_vc(z3_foo_vc))



