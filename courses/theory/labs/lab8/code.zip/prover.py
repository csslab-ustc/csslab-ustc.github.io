from z3 import *
from imp_ast import *


class Todo(Exception):
    pass


def vc_2_z3(vc: Exp):
    if isinstance(vc, ExpNum):
        return vc.num

    if isinstance(vc, ExpVar):
        return Int(vc.var)

    if isinstance(vc, ExpNeg):
        return Not(vc_2_z3(vc.exp))
    # TODO Exercise 5


def prove_vc(vc_z3):
    solver = Solver()
    solver.add(Not(vc_z3))
    ret = solver.check()
    if ret == unsat:
        return True
    else:
        print(solver.model())
        return False

