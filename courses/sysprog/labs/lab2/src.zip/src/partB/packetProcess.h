#ifndef MINIWIRESHARK_PACKETPROCESS_H
#define MINIWIRESHARK_PACKETPROCESS_H

void packet_print(unsigned char *buffer, int buffer_len);

#endif //MINIWIRESHARK_PACKETPROCESS_H