#include <stdio.h>
#include <string.h>
#include <net/ethernet.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <arpa/inet.h>
#include <netinet/ip_icmp.h>
#include "packetProcess.h"

struct sockaddr_in source, dest;
int total = 0, tcp = 0, udp = 0, icmp = 0, igmp = 0, other = 0, arp_packet = 0;
int ipheader_len;

// print format of etherNet-header
void mac_header(unsigned char *buffer){
    struct ethhdr *eth = (struct ethhdr*)(buffer);
    printf("\nEthernet Header\n");
    printf("\t|-Source Address      : %.2x-%.2x-%.2x-%.2x-%.2x-%.2x\n",
           eth->h_source[0], eth->h_source[1], eth->h_source[2],
           eth->h_source[3], eth->h_source[4], eth->h_source[5]);
    printf("\t|-Destination Address : %.2x-%.2x-%.2x-%.2x-%.2x-%.2x\n",
           eth->h_dest[0], eth->h_dest[1], eth->h_dest[2],
           eth->h_dest[3], eth->h_dest[4], eth->h_dest[5]);
    printf("\t|-Protocol            : %d\n", ntohs(eth->h_proto));
}

// print format of ip-header
void ip_header(unsigned char *buffer){
    /*
     * Todo("exercise 2 : Complete the code of Step 1 correctly, and submit your source code.")
     */
}

// print format of arp-header
void arp_header(unsigned char *buffer){
    /*
     * Todo("exercise 2 : Complete the code of Step 1 correctly, and submit your source code.")
     */
}

// print format of tcp-header
void tcp_header(unsigned char* buffer){
    /*
     * Todo("exercise 2 : Complete the code of Step 1 correctly, and submit your source code.")
     */
}

// print format of udp-header
void udp_header(unsigned char* buffer){
    /*
     * Todo("exercise 2 : Complete the code of Step 1 correctly, and submit your source code.")
     */
}

// print format of icmp-header
void icmp_header(unsigned char *buffer){
    /*
     * Todo("exercise 2 : Complete the code of Step 1 correctly, and submit your source code.")
     */
}

// print format of payload
void payload(unsigned char* buffer,int buffer_len){

    printf("\nData\n");
    for(int i=0; i<buffer_len; i++){
        if(i!=0 && i%16==0)
            printf("\n");
        printf(" %.2X ",buffer[i]);
    }

    printf("\n");
}

// print ICMP packet
void ICMP_printer(unsigned char *buffer, int buffer_len){
    printf("\n---------------------------ICMP Packet---------------------------");
    // print header
    mac_header(buffer);
    ip_header(buffer);
    icmp_header(buffer);
    // print packet payload
    unsigned char *data = (buffer + ipheader_len  + sizeof(struct ethhdr) + sizeof(struct icmphdr));
    int data_len = buffer_len - (ipheader_len  + sizeof(struct ethhdr) + sizeof(struct icmphdr));
    payload(data, data_len);
    printf("--------------------------------------------------------------\n\n\n");
}

// print ARP packet
void ARP_printer(unsigned char *buffer){
    /*
     * Todo("exercise 2 : Complete the code of Step 1 correctly, and submit your source code.")
     */
}

// print TCP packet
void TCP_printer(unsigned char *buffer, int buffer_len){
    /*
     * Todo("exercise 2 : Complete the code of Step 1 correctly, and submit your source code.")
     */
}

// print UDP packet
void UDP_printer(unsigned char* buffer, int buffer_len){
    /*
     * Todo("exercise 2 : Complete the code of Step 1 correctly, and submit your source code.")
     */
}

// packet process func
void packet_process(unsigned char* buffer, int buffer_len){
    ++total;
    struct ethhdr *eth = (struct ethhdr*)(buffer);
    switch((int) ntohs(eth->h_proto)){
        case 2048:{  // 0800 -> ip
            struct iphdr *ip = (struct iphdr*)(buffer + sizeof(struct ethhdr));
            switch(ip->protocol){
                case 1:                                     // ICMP packet
                    ++icmp;
                    ICMP_printer(buffer, buffer_len);
                    break;

                case 2:
                    ++igmp;
                    break;

                case 6:                                     // TCP packet
                    ++tcp;
                    TCP_printer(buffer, buffer_len);         // print packet info
                    break;

                case 17:                                    // UDP packet
                    ++udp;
                    UDP_printer(buffer,buffer_len);          // print packet info
                    break;

                default:
                    ++other;
            }
            break;
        }

        case 2054:  // 0806 -> arp
            ++arp_packet;
            ARP_printer(buffer);            // print ARP packet info
            break;

        default:
            ++other;
    }

    printf("Result: [TCP : %d], [UDP : %d], [ARP : %d], [ICMP : %d], [IGMP : %d], [OTHER : %d], [TOTAL : %d]\n",
           tcp, udp, arp_packet, icmp, igmp, other, total);
}