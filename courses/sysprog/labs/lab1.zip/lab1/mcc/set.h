

#ifndef SET_H
#define SET_H


void set_add(char *var);
int set_exists(char *var);
char *set_next();
void set_reset();


#endif

