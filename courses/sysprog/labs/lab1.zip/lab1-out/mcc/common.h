
#ifndef COMMON_H
#define COMMON_H


extern char *asm_file_name;
extern char *obj_file_name;


#endif

