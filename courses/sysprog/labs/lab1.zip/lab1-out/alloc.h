#ifndef ALLOC_H
#define ALLOC_H
#include <stdlib.h>
#define NEW(p) \

#define TODO()\
do{\
    extern int printf(char *, ...);\
    printf("Add your code here: file %s, line %d\n", __FILE__, __LINE__);\
}while(0)



do{            \
p = malloc(sizeof(*p)); \
}while(0)

#endif
