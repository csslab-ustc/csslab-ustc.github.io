#include <stdio.h>
#include "complex.h"


void Complex_init(Complex_t *c, int x, int y){
    c->arr[0] = x;
    c->arr[1] = y;
}

Complex_t Complex_add(Complex_t c1, Complex_t c2){
    Complex_t  c;
    c.arr[0] = c1.arr[0] + c2.arr[0];
    c.arr[1] = c1.arr[1] + c2.arr[1];
    return c;
}

void Complex_print(Complex_t c){
    printf("%d + %di\n", c.arr[0], c.arr[1]);
}



