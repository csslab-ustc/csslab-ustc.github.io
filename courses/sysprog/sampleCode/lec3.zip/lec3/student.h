
#ifndef LEC3_STUDENT_H
#define LEC3_STUDENT_H

////////////////
// student
// name, age, ...
struct student_t{
    char *name;
    int age;
};
typedef struct student_t Student_t;

void Student_init(Student_t *student, char *name, int age);
void Student_print(Student_t student);

#endif //LEC3_STUDENT_H
