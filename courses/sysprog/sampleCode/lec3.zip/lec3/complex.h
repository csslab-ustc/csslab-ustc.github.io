
#ifndef MYPROJECT_COMPLEX_H
#define MYPROJECT_COMPLEX_H
struct complex_t{
    int arr[2];
};

typedef struct complex_t Complex_t;

void Complex_init(Complex_t *c, int x, int y);
Complex_t Complex_add(Complex_t c1, Complex_t c2);
void Complex_print(Complex_t c);

#endif //MYPROJECT_COMPLEX_H
