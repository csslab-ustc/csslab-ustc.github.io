#include <stdio.h>
#include "student.h"
#include "complex.h"
#include "list.h"

int main() {
    printf("Hello, World!\n");
    // linked list
    List_t list = List_empty();
    List_insertFirst(list, 1);
    List_insertFirst(list, 2);
    List_insertFirst(list, 3);
    List_print(list);

    int x1, x2;
    Complex_t c1, c2;
    Complex_init(&c1, 1, 2);
    Complex_init(&c2, 2, 3);
    Complex_print(c1);
    Complex_print(c2);
    Complex_t c3 = Complex_add(c1, c2);
    Complex_print(c3);
    c3.arr[0]++;
    Complex_print(c3);

    // student
    Student_t student;
    Student_init(&student, "Alice", 20);
    Student_print(student);
    return 0;
}
