#include <stdio.h>
#include "student.h"

// operations
void Student_init(Student_t *student, char *name, int age){
    student->name = name;
    student->age = age;
}

void Student_print(Student_t student){
    printf("(%s, %d)\n", student.name, student.age);
}

// Student_getName(), Student_getAge()
