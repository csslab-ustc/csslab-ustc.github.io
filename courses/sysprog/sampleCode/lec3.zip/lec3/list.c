#include <stdlib.h>
#include <stdio.h>
#include "list.h"

// operations
List_t List_empty(){
    List_t list = malloc(sizeof(*list));
    list->data = -1;
    list->next = 0; // NULL
    return list;
}

int List_length(List_t list);

void List_insertFirst(List_t list, int data){
    List_t p = malloc(sizeof(*p));
    p->data = data;
    p->next = list->next;
    list->next = p;
}
void List_insertLast(List_t list, int data);
void List_print(List_t list){
    List_t p = list->next;
    printf("[");
    while(p != 0){
        printf("%d, ", p->data);
        p = p->next;
    }
    printf("]");
}
// ...