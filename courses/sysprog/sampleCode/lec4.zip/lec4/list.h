
#ifndef LEC4_LIST_H
#define LEC4_LIST_H

// CDT

struct list_t{
    int data;
    struct list_t *next;
};
typedef struct list_t *List_t;

// operations
List_t List_empty();
int List_length(List_t list);
void List_insertFirst(List_t list, int data);
void List_insertLast(List_t list, int data);
void List_print(List_t list);

// ADT operations
List_t List_getHead(List_t list);
int List_getData(List_t list);
List_t List_getNext(List_t list);

//int List_sum(List_t list);
//int List_prod(List_t list);

// ...

#endif //LEC4_LIST_H
