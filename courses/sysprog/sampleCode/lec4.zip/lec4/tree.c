#include <stdlib.h>
#include <stdio.h>
#include "tree.h"

Tree_t Tree_empty(){
    return 0;
}

Tree_t Tree_append(int data, Tree_t left, Tree_t right){
    Tree_t p = malloc(sizeof(*p));
//    if (0 == p){
//        error ...;
//    }
    p->data = data;
    p->left = left;
    p->right = right;
    return p;
}
void Tree_print(Tree_t tree){
    if (0 == tree)
        return;
    Tree_print(tree->left);
    printf("%d, ", tree->data);
    Tree_print(tree->right);
}