#include <stdio.h>
#include "student.h"
#include "list.h"
#include "tree.h"

int main() {
    // tree
    Tree_t tree = Tree_empty();
    Tree_print(tree);
    tree = Tree_append(5, tree, tree);
    Tree_print(tree);
    printf("\n");

    // linked list
    List_t list = List_empty();
    List_insertFirst(list, 1);
    List_insertFirst(list, 2);
    List_insertFirst(list, 3);

    // sum
    List_t p = list->next;
    int sum = 0;
    while(p){
        sum += p->data;
        p = p->next;
    }
    printf("sum=%d\n", sum);

    // ADT sum
//    List_t p = List_getHead(list);
//    int sum = 0;
//    while(p){
//        sum += List_getData(p);
//        p = List_getNext(p);
//    }
//    printf("sum=%d\n", sum);
//
//    List_print(list);

    // student
    Student_t  student =
            Student_new("Alice", 20);
    // student->id = "junk";
    *(((char *)student)+8) = "junk";
    Student_print(student);


    return 0;
}
