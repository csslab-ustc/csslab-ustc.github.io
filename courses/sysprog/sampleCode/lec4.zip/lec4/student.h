
#ifndef LEC4_STUDENT_H
#define LEC4_STUDENT_H

// ADT: abstract data type

typedef struct student_t *Student_t;

Student_t Student_new(char *name, int age);
void Student_print(Student_t student);

#endif //LEC4_STUDENT_H
