// This file is not written in CMakeLists.txt, thus does not belong to any project target and will not be compiled.
#include <stdio.h>
#include <stdlib.h>
#include "student.h"
////////////////
// student
// name, age, ...
// CDT: concrete data type
struct student_t{
    char *name;
    char *id;
    int age;
};

// operations
Student_t Student_new(char *name, int age){
    Student_t  student = malloc(sizeof(*student));
    student->name = name;
    student->id = "SA22225001";
    student->age = age;
    return student;
}

void Student_print(Student_t student){
    printf("(%s, %s, %d)\n", student->name, student->id, student->age);
}

// Student_getName(), Student_getAge()
