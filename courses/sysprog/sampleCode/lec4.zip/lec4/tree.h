#ifndef LEC4_TREE_H
#define LEC4_TREE_H

struct tree_t{
    int data;
    struct tree_t *left;
    struct tree_t *right;
};
typedef struct tree_t *Tree_t;

Tree_t Tree_empty();
Tree_t Tree_append(int data, Tree_t left, Tree_t right);
void Tree_print(Tree_t tree);
// ...

#endif //LEC4_TREE_H
