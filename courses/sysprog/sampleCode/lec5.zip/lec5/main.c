#include <stdio.h>
#include "list.h"

void before(){
    printf("<");
}

void after(){
    printf(">");
}

void printInt(int d){
    printf("%d, ", d);
}

void printInt2(int d){
    printf("\"%d\", ", d);
}

void printInt3(int d){
    printf("%%%d%%, ", d);
}

void printInt4(int d){
//    printf("%%%d%%, ", d);
}


int main() {
    // [3, 2, 1]
    List_t list = List_empty();
    List_insertFirst(list, 1);
    List_insertFirst(list, 2);
    List_insertFirst(list, 3);
    List_foreach(list,
                 before,
                 printInt,
                 after);

    // nested function, C doesn't support this
    List_foreach(list,
                 before,
                 printInt(int d){ // lambda
                     printf("%d, ", d);
                 },
                 after);

    // ["3", "2", "1"]
//    List_foreach(list, printInt2);
    // [%3%, %2%, %1%]
//    List_foreach(list, printInt3);
//    List_foreach(list, printInt4);

    // option1: iterator
    // for ;;;

    // option2: add a new API
    // List_print2(list);


    return 0;
}
