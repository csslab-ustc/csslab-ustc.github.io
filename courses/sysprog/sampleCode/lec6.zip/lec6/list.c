#include <stdlib.h>
#include <stdio.h>
#include "list.h"
//struct list_t{
//    int data;
//    struct list_t *next;
//};
// operations
List_t List_empty(){
    List_t list = malloc(sizeof(*list));
    list->data = -1;
    list->next = 0; // NULL
    return list;
}

int List_length(List_t list);

void List_insertFirst(List_t list, int data){
    List_t p = malloc(sizeof(*p));
    p->data = data;
    p->next = list->next;
    list->next = p;
}
void List_insertLast(List_t list, int data);
void List_foreach(List_t list,
                  void (*before)(),
                  void (*f)(int),
                  void (*after)()){
    List_t p = list->next;
//    printf("[");
    before();
    while(p != 0){
        f(p->data);
        p = p->next;
    }
//    printf("]");
    after();
}

List_t List_map(List_t list, int (*f)(int)){
    List_t newList = malloc(sizeof(*newList));
    List_t plist = newList;
    List_t oldList = list->next;
    while(oldList){
        List_t p = malloc(sizeof(*p));
        p->data = f(oldList->data);
        newList->next = p;
        newList = p;
        oldList = oldList->next;
    }
    newList->next = 0;
    return plist;
}

int List_reduce(List_t list, int init, int (*f)(int, int)){
    List_t oldList = list->next;
    while(oldList){
        init = f(init, oldList->data);
        oldList = oldList -> next;
    }
    return init;
}