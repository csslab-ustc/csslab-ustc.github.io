#include <stdio.h>
#include "list.h"

void before(){
    printf("<");
}

void after(){
    printf(">");
}

void printInt(int d){
    printf("%d, ", d);
}

void printInt2(int d){
    printf("\"%d\", ", d);
}

void printInt3(int d){
    printf("%%%d%%, ", d);
}

void printInt4(int d){
//    printf("%%%d%%, ", d);
}

int square(int x){
    return x * x;
}

int triple(int x){
    return x * x * x;
}

int add(int x, int y){
    return x + y;
}

int times(int x, int y){
    return x * y;
}

int main() {
    // [3, 2, 1]
    List_t list = List_empty();
    List_insertFirst(list, 1);
    List_insertFirst(list, 2);
    List_insertFirst(list, 3);
    List_foreach(list,
                 before,
                 printInt,
                 after);

    // ["3", "2", "1"]
//    List_foreach(list, printInt2);
    // [%3%, %2%, %1%]
//    List_foreach(list, printInt3);
//    List_foreach(list, printInt4);


    // [1, 2, 3] => [1, 4, 9]
    List_t list2 = List_map(list, square);
    List_foreach(list2,
                 before,
                 printInt,
                 after);

    List_t list3 = List_map(list, triple);
    List_foreach(list3,
                 before,
                 printInt,
                 after);

    // [1, 2, 3] => 0, ==> 6
    // [1, 2, 3] => 1, ==> 6
    printf("%d\n", List_reduce(list, 0, add));
    printf("list3 += %d\n", List_reduce(list3, 0, add));
    printf("list3 += %d\n", List_reduce(list3, 1, times));

    // [1, 2, 3] => x1*x1 + x2*x2 + x3*x3
    List_reduce(List_map(list, square),
    1,
    add);

    return 0;
}
