
#ifndef LEC6_LIST_H
#define LEC6_LIST_H

// CDT

struct list_t{
    int data;
    struct list_t *next;
};
typedef struct list_t *List_t;

// operations
List_t List_empty();
int List_length(List_t list);
void List_insertFirst(List_t list, int data);
void List_insertLast(List_t list, int data);
void List_foreach(List_t list,
                void (*before)(),
                void (*f)(int),
                void (*after)());
//option2
//void List_print2(List_t list);

// MapReduce
// [3, 2, 1] ==> [9, 4, 1]
List_t List_map(List_t list,
                int (*f)(int));

// [3, 2, 1] ==> 6(sum) / 6(product)
int List_reduce(List_t list,
                int init,
                int (*f)(int, int));

#endif //LEC6_LIST_H
