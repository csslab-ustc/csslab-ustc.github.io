#ifndef LEC7_COMPLEX_H
#define LEC7_COMPLEX_H


typedef struct complex_t *Complex_t;

Complex_t Complex_new(int x, int y);
Complex_t Complex_add(Complex_t c1, Complex_t c2);
int Complex_gt(Complex_t, Complex_t);
void Complex_print(Complex_t c);

#endif //LEC7_COMPLEX_H
