#include <stdio.h>
#include "complex.h"
#include "max.h"
#include "listx.h"
#include "list.h"

// subtype polymorphism
// void *
void *max(void *x, void *y, int(*gt)(void *, void *)){
    return gt(x, y)? x : y;
//    return x;
}

int gt_int(int *x, int *y){
    return *x > *y;
}

void b(){}
void f(int *x){
    printf("%d, ", *x);
}

int main() {
//    printf("%d\n", max_int(3, 4, operator >));
//    printf("%lf\n", max_double(3.14, 4.13));

//    struct List_double l = {.data = 0, .next = 0};
//    printf("%d\n", List_length_double(&l));

    int x = 3, y = 4;  // int *
    printf("%d\n", *(int *)max(&x, &y, gt_int));
    double xd = 3.14, yd = 4.13; // double *
//    printf("%lf\n", *(double *)max(&xd, &yd));

    Complex_t c1 = Complex_new(1, 2);
    Complex_t c2 = Complex_new(3, 4);
    Complex_t m = max(c1, c2, Complex_gt);
    Complex_print(m);

    List_t list = List_empty();
    List_insertFirst(list, &x);
    List_insertFirst(list, &y);
    List_foreach(list, b, f, b);
    printf("\n");

    // a list of complex
    List_t l = List_empty();
    List_insertFirst(l, Complex_new(1, 2));
    List_insertFirst(l, Complex_new(3, 4));
    List_foreach(l, b, Complex_print, b);

    Complex_print(List_reduce(l, Complex_new(0, 0), Complex_add));
    return 0;
}
