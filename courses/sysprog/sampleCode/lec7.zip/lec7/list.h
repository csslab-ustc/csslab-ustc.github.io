
#ifndef LEC7_LIST_H
#define LEC7_LIST_H
typedef void *poly;
struct list_t{
    poly data;
    struct list_t *next;
};
typedef struct list_t *List_t;

// operations
List_t List_empty();
int List_length(List_t list);
void List_insertFirst(List_t list, poly data);
void List_insertLast(List_t list, poly data);
void List_foreach(List_t list,
                  void (*before)(),
                  void (*f)(poly),
                  void (*after)());

// MapReduce
// [3, 2, 1] ==> [9, 4, 1]
List_t List_map(List_t list,
                poly (*f)(poly));

// [3, 2, 1] ==> 6(sum) / 6(product)
poly List_reduce(List_t list,
                poly init,
                poly (*f)(poly , poly));

#endif //LEC7_LIST_H
