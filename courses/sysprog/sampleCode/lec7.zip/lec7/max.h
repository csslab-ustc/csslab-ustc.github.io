#ifndef LEC7_MAX_H
#define LEC7_MAX_H
// parametric polymorphism
#define MAX(X) \
X max_##X(X x, X y, X(*gt)(X, X)){ \
    return gt(x, y)? x: y;\
}

MAX(int)
MAX(double)
MAX(float)
MAX(char)
//MAX(Complex_t)

/*
int max_int(int x, int y){
    return x>y? x: y;
}

double max_double(double x, double y){
    return x>y? x: y;
}
 */

#endif //LEC7_MAX_H
