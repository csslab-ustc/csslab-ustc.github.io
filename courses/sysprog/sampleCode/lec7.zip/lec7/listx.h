#ifndef LEC7_LISTX_H
#define LEC7_LISTX_H
// parametric polymorphism
#define LIST(X)\
struct List_##X{   \
    X data;\
    struct List *next;\
};             \
void List_insertFirst_##X(struct List_##X *l, X data) { \
return ;       \
}\
int List_length_##X(struct List_##X *l){\
    l = l->next;\
    int len = 0;\
    while(l){\
        len++;\
        l = l->next;\
    }\
    return len;\
}\


LIST(int)
LIST(double)
#endif //LEC7_LISTX_H
