#include <stdio.h>
#include <stdlib.h>
#include "complex.h"
struct complex_t{
    int arr[2];
};

Complex_t Complex_new(int x, int y){
    Complex_t c = malloc(sizeof(*c));
    c->arr[0] = x;
    c->arr[1] = y;
    return c;
}

Complex_t Complex_add(Complex_t c1, Complex_t c2){
    Complex_t c= malloc(sizeof(*c));
    c->arr[0] = c1->arr[0] + c2->arr[0];
    c->arr[1] = c1->arr[1] + c2->arr[1];
    return c;
}

int Complex_gt(Complex_t c1, Complex_t c2){
    return c1->arr[0] > c2->arr[0];
}


void Complex_print(Complex_t c){
    printf("%d + %di\n", c->arr[0], c->arr[1]);
}



