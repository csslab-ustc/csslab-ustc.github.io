#include <stdlib.h>
#include <stdio.h>
#include "list.h"

// poly data; == void *data;

// operations
List_t List_empty(){
    List_t list = malloc(sizeof(*list));
    list->data = 0;
    list->next = 0; // NULL
    return list;
}

int List_length(List_t list);

void List_insertFirst(List_t list, poly data){
    List_t p = malloc(sizeof(*p));
    p->data = data;
    p->next = list->next;
    list->next = p;
}
void List_insertLast(List_t list, poly data);
void List_foreach(List_t list,
                  void (*before)(),
                  void (*f)(poly),
                  void (*after)()){
    List_t p = list->next;
//    printf("[");
    before();
    while(p != 0){
        f(p->data);
        p = p->next;
    }
//    printf("]");
    after();
}

List_t List_map(List_t list, poly (*f)(poly)){
    List_t newList = malloc(sizeof(*newList));
    List_t plist = newList;
    List_t oldList = list->next;
    while(oldList){
        List_t p = malloc(sizeof(*p));
        p->data = f(oldList->data);
        newList->next = p;
        newList = p;
        oldList = oldList->next;
    }
    newList->next = 0;
    return plist;
}

poly List_reduce(List_t list,
                poly init,
                poly (*f)(poly, poly)){
    List_t oldList = list->next;
    while(oldList){
        init = f(init, oldList->data);
        oldList = oldList -> next;
    }
    return init;
}