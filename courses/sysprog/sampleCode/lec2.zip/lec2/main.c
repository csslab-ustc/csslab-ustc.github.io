#include <stdio.h>

// complex number
// c = x + yi
// data structures
// CDT: concrete data type
// ADT: abstract data type
struct complex_t{
    int arr[2];
};

typedef struct complex_t Complex_t;

// operations
void Complex_init(Complex_t *c, int x, int y){
    c->arr[0] = x;
    c->arr[1] = y;
}

Complex_t Complex_add(Complex_t c1, Complex_t c2){
    Complex_t  c;
    c.arr[0] = c1.arr[0] + c2.arr[0];
    c.arr[1] = c1.arr[1] + c2.arr[1];
    return c;
}

// Complex_sub(), Complex_times(), ...

void Complex_print(Complex_t c){
    printf("%d+%di\n", c.arr[0], c.arr[1]);
}

// ==========================================
int main() {
    printf("Hello, World!\n");
    int x1, x2;
    Complex_t  c1, c2;
    // c1.x = 1;
    // c1.y = 2;
    Complex_init(&c1, 1, 2);
    // c2.x = 2;
    // c2.y = 3;
    Complex_init(&c2, 2, 3);
    Complex_print(c1);
    Complex_print(c2);
    Complex_t c3 = Complex_add(c1, c2);
    Complex_print(c3);
    c3.arr[0]++;
    Complex_print(c3);

    return 0;
}
